import numpy as np
import cv2 as cv
img = cv.imread('sample_120.png')
img = cv.bilateralFilter(img,9,75,75)
mask = cv.imread('sample_120_mask.png', cv.IMREAD_GRAYSCALE)
dst = cv.inpaint(img,mask,3,cv.INPAINT_TELEA)
blur = cv.bilateralFilter(dst,9,75,75)
dst = cv.inpaint(blur,mask,3,cv.INPAINT_TELEA)
blur = cv.bilateralFilter(dst,9,75,75)
dst = cv.inpaint(blur,mask,3,cv.INPAINT_TELEA)
blur = cv.bilateralFilter(dst,9,75,75)
dst = cv.inpaint(blur,mask,3,cv.INPAINT_TELEA)


cv.imshow('dst',dst)
cv.imwrite('sample_120_inpaint.png',dst)

cv.waitKey(0)
cv.destroyAllWindows()