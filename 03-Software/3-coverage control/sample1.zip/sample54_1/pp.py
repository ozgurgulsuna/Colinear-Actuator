# import required libraries
import cv2
import numpy as np

# read the input image
img = cv2.imread('sample_54_1_inpaint.png')

# find the height and width of image
# width = number of columns, height = number of rows in image array
rows,cols,ch = img.shape

# define four points on input image 
pts1 = np.float32([[250,315],[1730,308],[90,455],[1920,465]])

# define the corresponding four points on output image
pts2 = np.float32([[320,390],[1650,390],[320,630],[1650,630]])

# get the perspective transform matrix
M = cv2.getPerspectiveTransform(pts1,pts2)

# transform the image using perspective transform matrix
dst = cv2.warpPerspective(img,M,(cols, rows))
cv2.imwrite('sample_54_1_inpaint_out.png',dst)
# display the transformed image
cv2.imshow('Transformed Image', dst)
cv2.waitKey(0)
cv2.destroyAllWindows()