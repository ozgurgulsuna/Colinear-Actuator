# import required libraries
import cv2
import numpy as np

# read the input image
img = cv2.imread('sample_120_4_inpaint.png')

# find the height and width of image
# width = number of columns, height = number of rows in image array
rows,cols,ch = img.shape

# define four points on input image 
pts1 = np.float32([[997,257],[1110,257],[968,366],[1154,356]])

# define the corresponding four points on output image
pts2 = np.float32([[997,335],[1087,335],[969,561],[1093,544]])

# get the perspective transform matrix
M = cv2.getPerspectiveTransform(pts1,pts2)

# transform the image using perspective transform matrix
dst = cv2.warpPerspective(img,M,(cols, rows))
cv2.imwrite('sample_120_4_inpaint_out.png',dst)
# display the transformed image
cv2.imshow('Transformed Image', dst)
cv2.waitKey(0)
cv2.destroyAllWindows()